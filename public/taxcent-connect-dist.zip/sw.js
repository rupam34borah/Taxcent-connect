/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "index.html",
    "revision": "051266b1edb3055d09ce60e77c16d031"
  }, {
    "url": "icon.svg",
    "revision": "80e90860381587cdee380040bc7ab03c"
  }, {
    "url": "icon-maskable-512x512.png",
    "revision": "f7365bb3afadcefb484196b46bc01ce4"
  }, {
    "url": "icon-512x512.png",
    "revision": "7b6edcf45a1a0b2536ca18d28f5301c1"
  }, {
    "url": "icon-192x192.png",
    "revision": "bfe8e2915b6e92b4b56d89944942d56e"
  }, {
    "url": "favicon.ico",
    "revision": "b6d10b90d3bed71cc1011f76feb03bf4"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "78badb6423a252e17631464373511ce1"
  }, {
    "url": "assets/index-DNc-pUo3.js",
    "revision": null
  }, {
    "url": "assets/index-C-xtTu1t.css",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261027-063421_b769013d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261027-062647_d07c352c.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261027-001648_4fa7145c.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "78badb6423a252e17631464373511ce1"
  }, {
    "url": "favicon.ico",
    "revision": "b6d10b90d3bed71cc1011f76feb03bf4"
  }, {
    "url": "icon-192x192.png",
    "revision": "bfe8e2915b6e92b4b56d89944942d56e"
  }, {
    "url": "icon-512x512.png",
    "revision": "7b6edcf45a1a0b2536ca18d28f5301c1"
  }, {
    "url": "icon-maskable-512x512.png",
    "revision": "f7365bb3afadcefb484196b46bc01ce4"
  }, {
    "url": "icon.svg",
    "revision": "80e90860381587cdee380040bc7ab03c"
  }, {
    "url": "manifest.webmanifest",
    "revision": "7c98b9e6d0c8969d134c1989ead46215"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
