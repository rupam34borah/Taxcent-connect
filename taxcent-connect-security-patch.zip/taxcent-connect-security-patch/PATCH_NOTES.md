# Taxcent Connect — focused security patch

This patch preserves the existing UI and project structure. It is a first security/schema pass, not a declaration that the whole application is production-ready.

## Files included

- `src/context/AuthContext.tsx`
  - Removes authentication restoration from editable localStorage.
  - Uses Supabase Auth sessions and resolves the user's role from an active `institute_staff` or `student_profiles` row linked by `user_id`.
  - Rejects role mismatch and rejects accounts without an active linked record.
  - Restricts demo accounts to Vite development builds and does not persist demo identities.
  - Uses registered email + password for login. Student-ID-only login is intentionally disabled until a secure server-side lookup is implemented.
- `src/components/AuthModal.tsx`
  - Removes `?demo=true` as a way to reveal demo accounts in production.
  - Updates login labels/placeholders to email-based login.
- `src/services/academicService.ts`
  - Removes a malformed stray object fragment in the initial demo documents that prevented TypeScript parsing.
  - Makes public certificate verification fail closed in production if the Supabase RPC is unavailable or Supabase is not configured. It no longer presents browser-local sample records as authoritative verification in production.
- `supabase/migrations/20261028_academic_schema.sql`
  - Adds compatibility columns where `CREATE TABLE IF NOT EXISTS` would otherwise leave the earlier certificate schema unchanged.
  - Resolves staff roles from trusted database records rather than JWT metadata.
  - Removes broad student self-update policy on protected enrollment/access fields.
  - Removes anonymous direct reads of mock-question rows containing correct answers.
  - Adds a fixed search path to the certificate verification function.
- `supabase/migrations/20261029_security_hardening.sql`
  - Idempotent role-helper/policy hardening for a database where the full academic schema already exists.
  - Adds a safe question-delivery RPC that omits answer keys and explanations.
- `docs/SUPABASE_SETUP.md`
  - Documents migration order and warns against using local/demo data for real student records.

## Apply safely

1. Back up the Supabase database before changing schema or policies.
2. Apply this patch to a separate development/staging copy of the project first.
3. For a **fresh staging database**, run migrations in order: `20261027_certificates_and_marksheets.sql`, the patched `20261028_academic_schema.sql`, then `20261029_security_hardening.sql`.
4. If your real Supabase project already has migration history or a partially failed migration, do **not** blindly rerun the modified 20261028 file. Compare the actual schema and migration history first; test a tailored repair migration on staging.
5. Test sign-in with one active student, one staff member and one admin. Also test a disabled account and an account with the wrong selected role.
6. Test anonymous and student attempts to select from `mock_questions`; they must not receive `correct_option_index`. Test the `get_mock_test_questions` RPC using an authenticated student and verify its result has no answer key.
7. Test certificate verification while online, with a failed RPC, and with Supabase unconfigured. Only a successful RPC response may be represented as an authoritative result.

## Known remaining blockers

- The academic service still has many localStorage-backed CRUD methods for courses, admissions, staff, attendance, marks, learning materials and mock tests. These need to be migrated to Supabase and protected with RLS before real academic records are used.
- The mock-test UI is not yet wired to `get_mock_test_questions`; that integration and server-side scoring must be completed before publishing real tests.
- Storage bucket policies must be configured and tested. A private bucket alone is not a complete authorization policy.
- Supabase SQL was statically reviewed but not executed against a live/staging database in this session.
- A full production build was not completed because this ZIP has no installed `node_modules`; the global TypeScript check was blocked by missing Vite type definitions. The pre-existing syntax error in `academicService.ts` was corrected, and the subsequent compiler pass reported missing type-definition packages rather than source syntax errors.

Do not use this patch as the sole basis for declaring Taxcent Connect production-ready.
