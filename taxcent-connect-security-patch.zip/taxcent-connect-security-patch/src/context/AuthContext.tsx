import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserRole } from '../types/academic';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'staff' | 'admin';
  studentIdCode?: string;
  studentId?: string;
  title?: string;
  courseName?: string;
}

export interface DemoAccount {
  role: 'student' | 'staff' | 'admin';
  name: string;
  email: string;
  identifier: string;
  studentId?: string;
  studentIdCode?: string;
  courseName?: string;
  description: string;
  password?: string;
}

export const DEMO_ACCOUNTS: DemoAccount[] = import.meta.env.DEV ? [
  {
    role: 'student',
    name: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    identifier: 'QLI-STU-2026-001',
    studentId: 'stu-001',
    studentIdCode: 'QLI-STU-2026-001',
    courseName: 'Diploma in Computer Application (DCA)',
    description: 'Enrolled Student with Valid DCA Marksheet & Certificate',
    password: 'student123',
  },
  {
    role: 'student',
    name: 'Rupam Borah',
    email: 'rupam.borah@example.com',
    identifier: 'QLI-STU-2026-004',
    studentId: 'stu-004',
    studentIdCode: 'QLI-STU-2026-004',
    courseName: 'Professional Tally Prime & GST Certification',
    description: 'Enrolled Student with Valid Tally & GST Certificate',
    password: 'student123',
  },
  {
    role: 'student',
    name: 'Ankita Bora',
    email: 'ankita.bora@example.com',
    identifier: 'QLI-STU-2026-002',
    studentId: 'stu-002',
    studentIdCode: 'QLI-STU-2026-002',
    courseName: 'Advance Diploma in Computer Application (ADCA)',
    description: 'Enrolled Student with Superseded/Revoked Credential Record',
    password: 'student123',
  },
  {
    role: 'staff',
    name: 'B. Bora (Academic Registrar)',
    email: 'staff@taxcent.in',
    identifier: 'staff@taxcent.in',
    description: 'Staff Hub: Authorized to input data, upload marksheets & view records',
    password: 'staff123',
  },
  {
    role: 'admin',
    name: 'Prof. D. Saikia (Principal & Admin)',
    email: 'admin@taxcent.in',
    identifier: 'admin@taxcent.in',
    description: 'Admin Console: Authorized to view all, approve, revoke & audit records',
    password: 'admin123',
  },
] : [];

interface AuthContextType {
  user: AuthUser | null;
  role: UserRole;
  isAuthenticated: boolean;
  isAuthModalOpen: boolean;
  authModalInitialRole: 'student' | 'staff' | 'admin';
  openAuthModal: (initialRole?: 'student' | 'staff' | 'admin') => void;
  closeAuthModal: () => void;
  login: (identifier: string, password?: string, requestedRole?: 'student' | 'staff' | 'admin') => Promise<{ success: boolean; error?: string }>;
  loginAsDemo: (account: DemoAccount) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/** Resolve roles from trusted database records, never from editable browser storage or user metadata. */
async function resolveDatabaseUser(authUser: { id: string; email?: string | null }): Promise<AuthUser | null> {
  if (!supabase) return null;

  const { data: staffRows, error: staffError } = await supabase
    .from('institute_staff')
    .select('*')
    .eq('user_id', authUser.id)
    .eq('is_active', true)
    .limit(1);

  if (staffError) throw new Error('Could not validate staff permissions. Please try again later.');
  const staff = staffRows?.[0] as Record<string, any> | undefined;
  if (staff && (staff.role === 'admin' || staff.role === 'staff') && staff.invitation_status !== 'revoked') {
    return {
      id: authUser.id,
      name: String(staff.full_name || authUser.email?.split('@')[0] || 'Staff member'),
      email: String(staff.email || authUser.email || ''),
      role: staff.role,
      title: staff.role === 'admin' ? 'Institutional Administrator' : String(staff.designation || 'Academic Office Staff'),
    };
  }

  const { data: studentRows, error: studentError } = await supabase
    .from('student_profiles')
    .select('*')
    .eq('user_id', authUser.id)
    .limit(1);

  if (studentError) throw new Error('Could not validate student access. Please try again later.');
  const student = studentRows?.[0] as Record<string, any> | undefined;
  if (student && student.is_portal_active !== false && student.enrolment_status !== 'suspended') {
    return {
      id: authUser.id,
      name: String(student.full_name || authUser.email?.split('@')[0] || 'Student'),
      email: String(student.email || authUser.email || ''),
      role: 'student',
      studentId: String(student.id),
      studentIdCode: String(student.student_id_code || ''),
      courseName: String(student.enrolled_course_name || student.enrolled_course || ''),
      title: 'Authorized Student',
    };
  }

  return null;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalInitialRole, setAuthModalInitialRole] = useState<'student' | 'staff' | 'admin'>('student');

  const clearUser = useCallback(() => setUser(null), []);

  useEffect(() => {
    if (!isSupabaseConfigured || !supabase) {
      clearUser();
      return;
    }

    let alive = true;
    const hydrate = async (authId: string, email?: string | null) => {
      try {
        const resolved = await resolveDatabaseUser({ id: authId, email });
        if (alive) setUser(resolved);
      } catch (error) {
        console.error('Session role validation failed:', error);
        if (alive) setUser(null);
      }
    };

    void supabase.auth.getSession().then(({ data, error }) => {
      if (error || !data.session?.user) {
        if (alive) setUser(null);
        return;
      }
      void hydrate(data.session.user.id, data.session.user.email);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session?.user) {
        if (alive) setUser(null);
        return;
      }
      // Do not await database calls inside Supabase's auth callback.
      void hydrate(session.user.id, session.user.email);
    });

    return () => {
      alive = false;
      listener.subscription.unsubscribe();
    };
  }, [clearUser]);

  const openAuthModal = (initialRole: 'student' | 'staff' | 'admin' = 'student') => {
    setAuthModalInitialRole(initialRole);
    setIsAuthModalOpen(true);
  };
  const closeAuthModal = () => setIsAuthModalOpen(false);

  const loginAsDemo = (account: DemoAccount) => {
    // Demo identities are deliberately development-only and are never persisted.
    if (!import.meta.env.DEV || !DEMO_ACCOUNTS.some(item => item.identifier === account.identifier && item.role === account.role)) return;
    setUser({
      id: account.studentId || `demo-${account.role}`,
      name: account.name,
      email: account.email,
      role: account.role,
      studentIdCode: account.studentIdCode,
      studentId: account.studentId,
      courseName: account.courseName,
      title: account.role === 'admin' ? 'Development Administrator' : account.role === 'staff' ? 'Development Staff' : 'Development Student',
    });
    closeAuthModal();
  };

  const login = async (
    identifier: string,
    password?: string,
    requestedRole: 'student' | 'staff' | 'admin' = 'student'
  ): Promise<{ success: boolean; error?: string }> => {
    if (!isSupabaseConfigured || !supabase) {
      return { success: false, error: 'Secure sign-in is not configured yet. Please contact the institute administrator.' };
    }

    const trimmed = identifier.trim().toLowerCase();
    if (!trimmed.includes('@')) {
      return { success: false, error: 'Please sign in with the email address linked to your institute account. Student-ID sign-in must be enabled through a secure server-side lookup first.' };
    }
    if (!password) return { success: false, error: 'Please enter your password.' };

    const { data, error } = await supabase.auth.signInWithPassword({ email: trimmed, password });
    if (error || !data.user) {
      return { success: false, error: 'Invalid email or password.' };
    }

    try {
      const resolved = await resolveDatabaseUser({ id: data.user.id, email: data.user.email });
      if (!resolved) {
        await supabase.auth.signOut();
        setUser(null);
        return { success: false, error: 'This account is not linked to an active student or staff record. Contact the institute administrator.' };
      }
      if (resolved.role !== requestedRole) {
        await supabase.auth.signOut();
        setUser(null);
        return { success: false, error: 'This account is not authorized for the selected portal.' };
      }
      setUser(resolved);
      closeAuthModal();
      return { success: true };
    } catch (error) {
      await supabase.auth.signOut();
      setUser(null);
      return { success: false, error: error instanceof Error ? error.message : 'Unable to validate your account permissions.' };
    }
  };

  const logout = () => {
    setUser(null);
    if (isSupabaseConfigured && supabase) void supabase.auth.signOut();
  };

  const currentRole: UserRole = user ? user.role : 'public';
  return (
    <AuthContext.Provider value={{
      user,
      role: currentRole,
      isAuthenticated: !!user,
      isAuthModalOpen,
      authModalInitialRole,
      openAuthModal,
      closeAuthModal,
      login,
      loginAsDemo,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
