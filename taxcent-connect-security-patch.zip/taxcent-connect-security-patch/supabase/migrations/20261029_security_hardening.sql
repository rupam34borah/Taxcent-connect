-- Taxcent Connect / Quantum Learning Institute
-- Security hardening patch for a database where the academic schema migration
-- has already completed successfully. Test on a staging project before production.

-- Derive roles from trusted database records, not user-editable JWT metadata.
CREATE OR REPLACE FUNCTION public.get_auth_role()
RETURNS VARCHAR
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
    SELECT COALESCE((
        SELECT s.role::text
        FROM public.institute_staff AS s
        WHERE s.user_id = auth.uid()
          AND s.is_active IS TRUE
          AND COALESCE(s.invitation_status, 'active') <> 'revoked'
        LIMIT 1
    ), 'public')::varchar;
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$ SELECT public.get_auth_role() = 'admin'; $$;

CREATE OR REPLACE FUNCTION public.is_staff()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$ SELECT public.get_auth_role() IN ('admin', 'staff'); $$;

-- Students must not edit their own enrollment, course, or portal-access flags.
DROP POLICY IF EXISTS "Student update own approved profile fields" ON public.student_profiles;

-- Never expose the correct_option_index column through direct student table reads.
DROP POLICY IF EXISTS "Anyone view test questions" ON public.mock_questions;
DROP POLICY IF EXISTS "Authenticated students view test questions" ON public.mock_questions;
-- Existing "Staff manage questions" policy remains the only direct SELECT path.

-- Safe question delivery RPC: answer keys and explanations are never returned.
CREATE OR REPLACE FUNCTION public.get_mock_test_questions(p_test_id UUID)
RETURNS TABLE (
    id UUID,
    test_id UUID,
    question_order INTEGER,
    question_text TEXT,
    question_text_as TEXT,
    options JSONB,
    marks INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Authentication required';
    END IF;

    IF NOT public.is_staff() AND NOT EXISTS (
        SELECT 1
        FROM public.student_profiles AS sp
        WHERE sp.user_id = auth.uid()
          AND COALESCE(sp.is_portal_active, TRUE) IS TRUE
          AND COALESCE(sp.enrolment_status, 'active') <> 'suspended'
    ) THEN
        RAISE EXCEPTION 'An active institute account is required';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM public.mock_tests AS mt
        WHERE mt.id = p_test_id
          AND (mt.is_published IS TRUE OR public.is_staff())
    ) THEN
        RAISE EXCEPTION 'Test not found or not published';
    END IF;

    RETURN QUERY
    SELECT q.id, q.test_id, q.question_order, q.question_text,
           q.question_text_as, q.options, q.marks
    FROM public.mock_questions AS q
    WHERE q.test_id = p_test_id
    ORDER BY q.question_order, q.id;
END;
$$;

REVOKE ALL ON FUNCTION public.get_mock_test_questions(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_mock_test_questions(UUID) TO authenticated;

-- Keep the public verification function on a fixed search_path if it already exists.
ALTER FUNCTION public.verify_certificate(TEXT) SET search_path = pg_catalog, public;
