# Quantum Learning Institute / Taxcent Connect
## Marksheets, Certificates & Public Verification Setup Guide

This guide details how to configure Supabase for Quantum Learning Institute's academic records, certificates, marksheets, and public verification system.

---

### 1. Create a Supabase Project
1. Log in to [https://supabase.com](https://supabase.com) and click **New Project**.
2. Set Name: `Taxcent-Quantum-Certificates`.
3. Choose your nearest database region (e.g., `ap-south-1` Mumbai or Singapore).
4. Save your database password securely.

---

### 2. Run database migrations (staging first)
1. Use a **staging/development Supabase project first**. Do not apply schema changes to a live student database without a backup and a reviewed migration plan.
2. Run `supabase/migrations/20261027_certificates_and_marksheets.sql`.
3. Run `supabase/migrations/20261028_academic_schema.sql`.
4. If the academic schema migration has completed successfully, run `supabase/migrations/20261029_security_hardening.sql`.
5. Verify each migration completes without errors, then test RLS with anonymous, student, staff and admin accounts.

The 20261028 migration was updated to reconcile overlapping tables from the earlier certificates migration. If an earlier attempt at that migration failed or partially applied, **do not blindly rerun it against production**: inspect the actual database schema and repair it on staging first. The 20261029 patch assumes the full academic schema exists.

---

### 3. Create Storage Bucket for Documents
1. In the Supabase Dashboard, navigate to **Storage**.
2. Click **New Bucket**.
3. Name: `academic-documents`
4. **Important**: Leave **Public bucket** switched **OFF** (Private).
   - This prevents unauthorized visitors from guessing URLs to inspect student marks or files.
   - Files are securely retrieved via short-lived authenticated Signed URLs (`createSignedUrl`).
5. Set allowed MIME types (optional): `application/pdf`, `image/png`, `image/jpeg`.
6. Set max file size limit: `5MB`.

---

### 4. Configure Environment Variables
Copy `.env.example` to `.env` or set in your hosting platform (Vercel, Netlify, or GitHub Secrets):

```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

> **Security Note:** Never expose the `SUPABASE_SERVICE_ROLE_KEY` in frontend client code. Only use the public `VITE_SUPABASE_ANON_KEY`. All security and role separation is enforced at the PostgreSQL database level using Row Level Security (RLS) and the `verify_certificate` SECURITY DEFINER function.

---

### 5. Development preview only
Local/demo data may be useful while developing the interface, but it is **not an authoritative or secure record store**. Do not enter real student data, passwords, marks, certificates or uploaded documents when Supabase is unavailable. Production sign-in must fail closed when Supabase is missing or unreachable; never treat local browser storage as authentication or a source of truth.

Before launch, verify that every academic operation is backed by Supabase and protected by RLS. The current UI/service layer still contains local/demo academic data paths that must be migrated to database-backed operations before real student records are used.
